package com.example.mafiaoverlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var resultView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xEE20242B.toInt())
        }
        val header = TextView(this).apply {
            text = "MAFIA HELPER  •  ⋮"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        resultView = TextView(this).apply {
            text = "Ожидаю распознанный текст…"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 8)
        }
        val close = Button(this).apply {
            text = "Скрыть"
            setOnClickListener { stopSelf() }
        }
        root.addView(header)
        root.addView(resultView)
        root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 160 }
        panel = root
        wm.addView(root, params)
        CaptureService.onRecognizedText = { text ->
            resultView?.post { resultView?.text = text.take(1200).ifBlank { "Текст не найден" } }
        }
    }

    override fun onDestroy() {
        CaptureService.onRecognizedText = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
